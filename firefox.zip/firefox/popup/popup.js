document.addEventListener('DOMContentLoaded', () => {
  const inputs = {
    brightness: document.getElementById('brightness'),
    contrast: document.getElementById('contrast'),
    saturation: document.getElementById('saturation'),
    hue: document.getElementById('hue'),
    invert: document.getElementById('invert'),
    sepia: document.getElementById('sepia'),
    temperature: document.getElementById('temperature'),
    tint: document.getElementById('tint'),
    highlights: document.getElementById('highlights'),
    shadows: document.getElementById('shadows'),
    redBalance: document.getElementById('red-balance'),
    greenBalance: document.getElementById('green-balance'),
    blueBalance: document.getElementById('blue-balance')
  };

  const displays = {
    brightness: document.getElementById('brightness-val'),
    contrast: document.getElementById('contrast-val'),
    saturation: document.getElementById('saturation-val'),
    hue: document.getElementById('hue-val'),
    invert: document.getElementById('invert-val'),
    sepia: document.getElementById('sepia-val'),
    temperature: document.getElementById('temperature-val'),
    tint: document.getElementById('tint-val'),
    highlights: document.getElementById('highlights-val'),
    shadows: document.getElementById('shadows-val')
  };

  const resetButton = document.getElementById('reset');
  const popOutButton = document.getElementById('pop-out');
  const pinButton = document.getElementById('pin-window');

  let targetTabId = null;

  // Determine target tab
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.has('tabId')) {
    targetTabId = parseInt(urlParams.get('tabId'));
    init(targetTabId);
    // Hide pop-out button if already popped out
    popOutButton.style.display = 'none';
    // Show pin button
    pinButton.style.display = 'inline-block';
  } else {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        targetTabId = tabs[0].id;
        init(targetTabId);
      }
    });
    // Hide pin button in normal popup (not supported)
    pinButton.style.display = 'none';
  }

  function init(tabId) {
    const storageKey = `settings_${tabId}`;
    
    // Load saved settings
    chrome.storage.local.get([storageKey], (result) => {
      if (result[storageKey]) {
        Object.keys(inputs).forEach(key => {
          if (result[storageKey][key] !== undefined) {
            inputs[key].value = result[storageKey][key];
            updateDisplay(key, result[storageKey][key]);
          }
        });
      }
    });

    // Add event listeners
    Object.keys(inputs).forEach(key => {
      inputs[key].addEventListener('input', (e) => {
        const value = e.target.value;
        updateDisplay(key, value);
        updateFilter();
      });
    });

    resetButton.addEventListener('click', () => {
      inputs.brightness.value = 100;
      inputs.contrast.value = 100;
      inputs.saturation.value = 100;
      inputs.hue.value = 0;
      inputs.invert.value = 0;
      inputs.sepia.value = 0;
      inputs.temperature.value = 0;
      inputs.tint.value = 0;
      inputs.highlights.value = 0;
      inputs.shadows.value = 0;
      inputs.redBalance.value = 0;
      inputs.greenBalance.value = 0;
      inputs.blueBalance.value = 0;

      Object.keys(inputs).forEach(key => {
        updateDisplay(key, inputs[key].value);
      });
      updateFilter();
    });
  }

  // Pop Out Handler
  popOutButton.addEventListener('click', () => {
    if (targetTabId) {
      chrome.windows.create({
        url: chrome.runtime.getURL(`popup/popup.html?tabId=${targetTabId}`),
        type: 'popup',
        width: 340,
        height: 600
      });
      window.close(); // Close the original popup
    }
  });

  // Pin Handler (Always on Top)
  pinButton.addEventListener('click', () => {
    chrome.windows.getCurrent((window) => {
      // Toggle state
      const newState = !window.alwaysOnTop;
      
      // Attempt to update
      chrome.windows.update(window.id, { alwaysOnTop: newState }, () => {
        if (chrome.runtime.lastError) {
          console.warn("Always on top update failed:", chrome.runtime.lastError.message);
          // If it failed, it might be because we are in a normal popup or lack permission.
          // Try to create a new window with the property if we were just popping out? 
          // No, we are already in the window.
          
          // Visual feedback of failure (shake or red flash could be added, but for now just don't toggle active)
          alert("Always on Top is not supported in this mode.");
        } else {
          // Success
          pinButton.classList.toggle('active', newState);
        }
      });
    });
  });

  function updateDisplay(key, value) {
    if (!displays[key]) return; 
    
    let suffix = '';
    if (key === 'hue') suffix = 'deg';
    else if (['brightness', 'contrast', 'saturation', 'invert', 'sepia'].includes(key)) suffix = '%';
    
    displays[key].textContent = value + suffix;
  }

  function updateFilter() {
    if (!targetTabId) return;

    const settings = {};
    Object.keys(inputs).forEach(key => {
      settings[key] = inputs[key].value;
    });

    // Save settings specific to tab
    const storageKey = `settings_${targetTabId}`;
    chrome.storage.local.set({ [storageKey]: settings });

    // Send to specific tab
    chrome.tabs.sendMessage(targetTabId, {
      type: 'UPDATE_FILTER',
      settings: settings
    });
  }
});
