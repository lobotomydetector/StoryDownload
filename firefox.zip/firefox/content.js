let currentSettings = {
  brightness: 100,
  contrast: 100,
  saturation: 100,
  hue: 0,
  invert: 0,
  sepia: 0,
  temperature: 0,
  tint: 0,
  highlights: 0,
  shadows: 0,
  redBalance: 0,
  greenBalance: 0,
  blueBalance: 0
};

// SVG Filter ID
const FILTER_ID = 'video-color-grade-filter';
let tabId = null;

// Initialize
chrome.runtime.sendMessage({ type: 'GET_TAB_ID' }, (response) => {
  if (response && response.tabId) {
    tabId = response.tabId;
    const storageKey = `settings_${tabId}`;
    
    chrome.storage.local.get([storageKey], (result) => {
      if (result[storageKey]) {
        currentSettings = { ...currentSettings, ...result[storageKey] };
        injectSvgFilter();
        applyFilters();
      }
    });
  }
});

// Listen for messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'UPDATE_FILTER') {
    currentSettings = { ...currentSettings, ...message.settings };
    applyFilters();
  }
});

function injectSvgFilter() {
  if (document.getElementById(FILTER_ID)) return;

  const svgNS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNS, "svg");
  svg.id = "video-color-grade-svg";
  svg.style.position = "absolute";
  svg.style.width = "0";
  svg.style.height = "0";
  svg.style.pointerEvents = "none";

  const filter = document.createElementNS(svgNS, "filter");
  filter.id = FILTER_ID;

  // Temperature/Tint/RGB (Color Matrix)
  const feColorMatrix = document.createElementNS(svgNS, "feColorMatrix");
  feColorMatrix.id = "vcg-color-matrix";
  feColorMatrix.setAttribute("type", "matrix");
  feColorMatrix.setAttribute("values", "1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 1 0");
  filter.appendChild(feColorMatrix);

  // Highlights/Shadows (Component Transfer)
  const feComponentTransfer = document.createElementNS(svgNS, "feComponentTransfer");
  feComponentTransfer.id = "vcg-component-transfer";
  
  ['R', 'G', 'B'].forEach(channel => {
    const func = document.createElementNS(svgNS, `feFunc${channel}`);
    func.setAttribute("type", "table"); // Use table for curve mapping
    func.setAttribute("tableValues", "0 1");
    feComponentTransfer.appendChild(func);
  });

  filter.appendChild(feComponentTransfer);
  svg.appendChild(filter);
  document.body.appendChild(svg);
}

function applyFilters() {
  // Ensure SVG exists
  injectSvgFilter();

  // 1. CSS Filters (Standard)
  const cssFilterString = `
    brightness(${currentSettings.brightness}%)
    contrast(${currentSettings.contrast}%)
    saturate(${currentSettings.saturation}%)
    hue-rotate(${currentSettings.hue}deg)
    invert(${currentSettings.invert}%)
    sepia(${currentSettings.sepia}%)
    url(#${FILTER_ID})
  `;

  // 2. SVG Filter Logic

  // --- Temperature & Tint & RGB Balance ---
  // Simplified approximation:
  // Temp: Blue <-> Orange (adjust R and B channels)
  // Tint: Green <-> Magenta (adjust G channel)
  // RGB Balance: Direct channel scaling
  
  const temp = parseInt(currentSettings.temperature) / 100; // -1 to 1
  const tint = parseInt(currentSettings.tint) / 100; // -1 to 1
  const rBal = parseInt(currentSettings.redBalance) / 50; // -1 to 1
  const gBal = parseInt(currentSettings.greenBalance) / 50;
  const bBal = parseInt(currentSettings.blueBalance) / 50;

  // Base identity
  let r = 1, g = 1, b = 1;

  // Temperature (Warm = +Red, -Blue; Cool = -Red, +Blue)
  r += temp * 0.2;
  b -= temp * 0.2;

  // Tint (Green = +Green; Magenta = -Green)
  g += tint * 0.2;

  // RGB Balance
  r += rBal * 0.5;
  g += gBal * 0.5;
  b += bBal * 0.5;

  const matrixValues = `
    ${r} 0 0 0 0
    0 ${g} 0 0 0
    0 0 ${b} 0 0
    0 0 0 1 0
  `;
  
  const colorMatrix = document.getElementById('vcg-color-matrix');
  if (colorMatrix) colorMatrix.setAttribute("values", matrixValues);


  // --- Highlights & Shadows ---
  // We use feComponentTransfer with type="table" to map luminance.
  // Shadows affects the low end (0.0 - 0.5), Highlights affects high end (0.5 - 1.0).
  // This is a simplified curve generation.
  
  const shadows = parseInt(currentSettings.shadows) / 100; // -1 to 1
  const highlights = parseInt(currentSettings.highlights) / 100; // -1 to 1

  // Generate table values (gamma curve approximation)
  // 10 points from 0 to 1
  const steps = 10;
  let tableValues = [];
  for (let i = 0; i <= steps; i++) {
    let x = i / steps;
    let y = x;

    // Apply Shadows (affects x < 0.4 mostly)
    if (x < 0.4) {
        // Smooth curve affecting darks
        let factor = 1 - (x / 0.4);
        y += shadows * factor * factor * 0.2; 
    }
    
    // Apply Highlights (affects x > 0.6 mostly)
    if (x > 0.6) {
        // Smooth curve affecting lights
        let factor = (x - 0.6) / 0.4;
        y += highlights * factor * factor * 0.2; 
    }
    
    // Clamp
    y = Math.max(0, Math.min(1, y));
    tableValues.push(y);
  }
  
  const tableString = tableValues.join(' ');
  const componentTransfer = document.getElementById('vcg-component-transfer');
  if (componentTransfer) {
    Array.from(componentTransfer.children).forEach(func => {
        func.setAttribute("tableValues", tableString);
    });
  }


  // Apply to videos
  const videos = document.querySelectorAll('video');
  videos.forEach(video => {
    video.style.filter = cssFilterString;
    video.style.webkitFilter = cssFilterString;
  });
}

// Handle dynamic content
const observer = new MutationObserver((mutations) => {
  let shouldUpdate = false;
  mutations.forEach(mutation => {
    if (mutation.addedNodes.length) {
      mutation.addedNodes.forEach(node => {
        if (node.nodeName === 'VIDEO' || (node.querySelectorAll && node.querySelectorAll('video').length > 0)) {
          shouldUpdate = true;
        }
      });
    }
  });

  if (shouldUpdate) {
    applyFilters();
  }
});

observer.observe(document.body, {
  childList: true,
  subtree: true
});
